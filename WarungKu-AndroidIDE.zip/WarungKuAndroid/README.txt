WarungKu AndroidIDE project
Open this folder in AndroidIDE as an existing Gradle project.
Expected SDK: compileSdk 34
Expected JDK: 17
Android Gradle Plugin: 8.2.2
Gradle: 8.2
